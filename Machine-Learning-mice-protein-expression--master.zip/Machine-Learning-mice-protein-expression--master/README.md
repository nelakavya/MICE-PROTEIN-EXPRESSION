# Machine-Learning-mice-protein-expression-
### Description
This project is using datasets from UCI Machine Learning Repository (https://archive.ics.uci.edu/ml/datasets/Mice+Protein+Expression) to identify proteins critical to learning ability of Down syndrome mouse model. The goal of this project is to understand which trisomy protein classes that contribute to the success and the failure of mice learning. Decision tree and random forest were used to model and predict the mice class and predict which proteins were critical for each class.
The full report can be read on https://drive.google.com/file/u/1/d/1V3FDYNBV9z3-41YcbnYakEGrQSePHI70/view

